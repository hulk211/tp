import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.*;
import java.util.Timer;

/**
 * Write a description of class enemy1 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class enemy1 extends Actor
{
    /**
     * Act - do whatever the enemy1 wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    private final int GRAVITY = 1;
    private int velocity;
    int xm = 2;
    SimpleTimer timer = new SimpleTimer();
    public enemy1(){
        velocity = 0;
    }
    public void act()
    {
        fall();
        move();   
        if(timer.millisElapsed()>3000)
        {
            getWorld().addObject(new balae(),getX(),getY());
            timer.mark();
        }
    }
    public void fall(){
        setLocation(getX(),getY()+velocity);
        if(getY()>getWorld().getHeight()-98) velocity =0;
        else velocity += GRAVITY;
    }
    public void jump(){
        velocity = -20;
    }
    public void move(){
         int x = getX();
        int y = getY();
      
       if(x>550)
       {
           xm *= -1;
        }
         if(x<10)
       {
           xm *= -1;
        }
         setLocation(x+xm,y);
            }
            
    
}
