import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class bala here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class bala extends Actor
{
    /**
     * Act - do whatever the bala wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
       setLocation(getX()+3,getY());
       Actor enemy1 = getOneIntersectingObject(enemy1.class);
       if(enemy1 != null)
       {
           getWorld().removeObject(enemy1);
           
        }
        if(getX()>590)
        {
            getWorld().removeObject(this);
        }
    }
}
