import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class MyWorld4 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class MyWorld4 extends World
{

    /**
     * Constructor for objects of class MyWorld4.
     * 
     */
    public MyWorld4()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(600, 400, 1); 
        prepare();
    }
    
    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    private void prepare()
    {
        enemy1 enemy1 = new enemy1();
        addObject(enemy1,422,303);
        enemy1 enemy12 = new enemy1();
        addObject(enemy12,498,301);
        enemy1 enemy13 = new enemy1();
        addObject(enemy13,574,301);
        mainc3 mainc3 = new mainc3();
        addObject(mainc3,5,307);
        enemy13.setLocation(551,300);
        enemy1.setLocation(437,305);
        removeObject(enemy1);
        enemy12.setLocation(303,298);
    }
    public void act()
    {
        if(Greenfoot.isKeyDown("enter"))
            Greenfoot.setWorld(new es2());
    }
}
