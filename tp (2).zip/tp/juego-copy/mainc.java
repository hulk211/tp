import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class mainc here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class mainc extends Actor
{
    /**
     * Act - do whatever the mainc wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
        move();
        Greenfoot.playSound("rr.mp3");
        
    }
    public void move(){
        int x = getX();
        int y = getY();
        
        if(Greenfoot.isKeyDown("A"))x--;
        
        if(Greenfoot.isKeyDown("D"))x++;
        setLocation(x,y);
        if (x == 800 && y == y)
        Greenfoot.setWorld(new MyWorld2());

            }
}
