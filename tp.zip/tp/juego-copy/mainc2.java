import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class mainc2 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class mainc2 extends Actor
{
    /**
     * Act - do whatever the mainc2 wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
        move();
        
    }
    public void move(){
        int x = getX();
        int y = getY();
        if(x<200)x++;
        setLocation(x,y);
        if (x == 199 && y == y)
        Greenfoot.setWorld(new myWorld3());
            }
}
