import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class MyWorld2 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class MyWorld2 extends World
{

    /**
     * Constructor for objects of class MyWorld2.
     * 
     */
    public MyWorld2()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(600, 400, 1); 
        prepare();
    }
    
    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    private void prepare()
    {
        mainc2 mainc2 = new mainc2();
        addObject(mainc2,11,311);
        enemy1 enemy1 = new enemy1();
        addObject(enemy1,406,303);
        enemy1 enemy12 = new enemy1();
        addObject(enemy12,538,305);
        enemy1 enemy13 = new enemy1();
        addObject(enemy13,452,302);
        enemy13.setLocation(448,296);
        removeObject(enemy13);
        prin prin = new prin();
        addObject(prin,504,302);
        enemy2 enemy2 = new enemy2();
        addObject(enemy2,456,301);
        prin.setLocation(490,298);
        enemy2.setLocation(464,299);
        sp sp = new sp();
        addObject(sp,472,208);
        enemy1.setLocation(409,299);
        enemy2 enemy22 = new enemy2();
        addObject(enemy22,364,300);
        enemy1.setLocation(400,301);
        removeObject(enemy1);
        enemy22.setLocation(404,295);
        enemy22.setLocation(401,309);
        enemy22.setLocation(408,303);
        removeObject(enemy12);
    }
}
