import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class sp here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class sp extends Actor
{
    /**
     * Act - do whatever the sp wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
    
    Greenfoot.playSound("Metalg.mp3");  
    
}
}
