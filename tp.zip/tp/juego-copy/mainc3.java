import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class mainc3 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class mainc3 extends Actor
{
    /**
     * Act - do whatever the mainc3 wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
     private final int GRAVITY = 1;
    private int velocity;
    public mainc3(){
        velocity = 0;
    }
    public void act()
    {
        move();
       fall();
       if (Greenfoot.isKeyDown("w") && getY()>getWorld().getHeight()-98) jump();
    
    }
    public void fall(){
        setLocation(getX(),getY()+velocity);
        if(getY()>getWorld().getHeight()-98) velocity =0;
        else velocity += GRAVITY;
    }
    public void jump(){
        velocity = -20;
    }
     public void move(){
        int x = getX();
        int y = getY();
        
        if(Greenfoot.isKeyDown("A"))x--;
        
        if(Greenfoot.isKeyDown("D"))x++;
        setLocation(x,y);
        if (Greenfoot.isKeyDown("space"))
        {
            getWorld().addObject(new bala(),x,y);
        }
        if (x >590)
        Greenfoot.setWorld(new MyWorld4());
    }
}
